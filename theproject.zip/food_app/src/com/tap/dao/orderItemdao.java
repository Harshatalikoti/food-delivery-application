package com.tap.dao;

import java.util.List;
import com.tap.model.*;

public interface orderItemdao {
	void addOrderItem(orderItem orderitem);
	orderItem getorderItem(int orderItemId);
	void updateorderItem(orderItem orderItem);
	void deleteOrderItem(int orderItemId);
	List<orderItem> getorderItemByOrder(int orderId);
}
