package com.tap.daoimplementation;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tap.model.orderItem;
import com.tap.utility.DBconnection;

public class orderItemDaoImpl {

    private static final String INSERT_ORDER_ITEM_QUERY = "INSERT INTO `order_item`(`orderId`, `menuId`, `quantity`, `totalPrice`) VALUES (?, ?, ?, ?)";
    private static final String GET_ORDER_ITEM_QUERY = "SELECT * FROM `order_item` WHERE `orderItemId` = ?";
    private static final String UPDATE_ORDER_ITEM_QUERY = "UPDATE `order_item` SET `orderId` = ?, `menuId` = ?, `quantity` = ?, `totalPrice` = ? WHERE `orderItemId` = ?";
    private static final String DELETE_ORDER_ITEM_QUERY = "DELETE FROM `order_item` WHERE `orderItemId` = ?";
    private static final String GET_ORDER_ITEMS_BY_ORDER_QUERY = "SELECT * FROM `order_item` WHERE `orderId` = ?";

    public void addOrderItem(orderItem orderItem) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ORDER_ITEM_QUERY)) {

            preparedStatement.setInt(1, orderItem.getOrderId());
            preparedStatement.setInt(2, orderItem.getMenuId());
            preparedStatement.setInt(3, orderItem.getQuantity());
            preparedStatement.setInt(4, orderItem.getTotalPrice());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public orderItem getOrderItem(int orderItemId) {
        orderItem orderItem = null;
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(GET_ORDER_ITEM_QUERY)) {

            preparedStatement.setInt(1, orderItemId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                orderItem = extractOrderItem(resultSet);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItem;
    }

    public void updateOrderItem(orderItem orderItem) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_ORDER_ITEM_QUERY)) {

            preparedStatement.setInt(1, orderItem.getOrderId());
            preparedStatement.setInt(2, orderItem.getMenuId());
            preparedStatement.setInt(3, orderItem.getQuantity());
            preparedStatement.setInt(4, orderItem.getTotalPrice());
            preparedStatement.setInt(5, orderItem.getOrderItemId());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteOrderItem(int orderItemId) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_ORDER_ITEM_QUERY)) {

            preparedStatement.setInt(1, orderItemId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<orderItem> getOrderItemsByOrder(int orderId) {
        List<orderItem> orderItems = new ArrayList<>();
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(GET_ORDER_ITEMS_BY_ORDER_QUERY)) {

            preparedStatement.setInt(1, orderId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                orderItem orderItem = extractOrderItem(resultSet);
                orderItems.add(orderItem);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItems;
    }

    private orderItem extractOrderItem(ResultSet resultSet) throws SQLException {
        int orderItemId = resultSet.getInt("orderItemId");
        int orderId = resultSet.getInt("orderId");
        int menuId = resultSet.getInt("menuId");
        int quantity = resultSet.getInt("quantity");
        int totalPrice = resultSet.getInt("totalPrice");

        return new orderItem(orderItemId, orderId, menuId, quantity, totalPrice);
    }

    public static void main(String[] args) {
        orderItemDaoImpl dao = new orderItemDaoImpl();
        System.out.println("DAO Implementation Loaded Successfully");
    }
}
