/**
 * 
 */
/**
 * 
 */
module food_app {
	requires java.sql;
}